document.querySelector('form').addEventListener('submit', function(e) {
    var password = document.querySelector('input[name="password"]').value;
    var confirm_password = document.querySelector('input[name="confirm_password"]').value;

    if (password !== confirm_password) {
        e.preventDefault();
        alert('Passwords do not match!');
    }
});
